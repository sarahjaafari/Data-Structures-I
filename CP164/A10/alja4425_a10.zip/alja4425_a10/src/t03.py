"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Sara Aljaafari
ID:      169044425
Email:   alja4425@mylaurier.ca
__updated__ = '2023-04-10'
-------------------------------------------------------
"""
# Imports
from Sorts_array import Sorts

a = [45, 67, 67, 6, 78, 879, 78, 9987, 345]

Sorts.gnome_sort(a)

print("sorted: {}".format(a))
