"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Sara Aljaafari
ID:      169044425
Email:   alja4425@mylaurier.ca
__updated__ = '2023-04-10'
-------------------------------------------------------
"""
# Imports
from Sorts_array import Sorts

a = [23, 234, 54, 56, 67, 567, 87, 23]

Sorts.radix_sort(a)

print("sorted Array: {}".format(a))
